# -*- coding: utf-8 -*-
# HelloWorld: the smallest possible host. No website - one folder with three YouTube videos,
# which the urlparser (libs/urlparser.py) turns into playable streams.
# Wiki: https://github.com/oe-mirrors/e2iplayer/wiki/Adding-a-new-host-in-E2iplayer
###################################################
# LOCAL import
###################################################
from Plugins.Extensions.IPTVPlayer.components.ihost import CBaseHostClass, CHostBase
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc
###################################################


def GetConfigList():
    # options of the host (BLUE key in the host list) - none here
    return []


def gettytul():
    # shown as the title of the host
    return 'https://helloworld.com/'


class HelloWorld(CBaseHostClass):

    def __init__(self):
        # names of the search history file and the cookie file (in the E2iPlayer cache folder)
        CBaseHostClass.__init__(self, {'history': 'helloworld', 'cookie': 'helloworld.cookie'})
        self.MAIN_URL = gettytul()
        self.MENU = [{'category': 'list_videos', 'title': _('Videos')}]

    def listVideos(self, cItem):
        printDBG('HelloWorld.listVideos')
        # every row is a dict: 'title', 'url', 'icon' (cover) and 'desc' are used by E2iPlayer,
        # any other key is yours and comes back in cItem when the row is opened
        for title, videoId in (('Big Buck Bunny', 'aqz-KE-bpKQ'), ('Sintel', 'eRsGyueVLvQ'), ('Tears of Steel', 'R6MlUcmOul8')):
            self.addVideo({'name': 'category', 'good_for_fav': True, 'title': title,
                           'url': 'https://www.youtube.com/watch?v=' + videoId,
                           'icon': 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % videoId,
                           'desc': _('Open movie by the Blender Foundation')})

    def getLinksForVideo(self, cItem):
        # called when a VIDEO row is opened: list of {'name', 'url', 'need_resolve'}
        printDBG('HelloWorld.getLinksForVideo [%s]' % cItem)
        # a link to a known video hoster: let the urlparser find the stream
        return self.up.getVideoLinkExt(cItem['url'])

    def handleService(self, index, refresh=0, searchPattern='', searchType=''):
        # called for every list the user opens; self.currItem is the row that was selected
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)
        name = self.currItem.get('name', '')
        category = self.currItem.get('category', '')
        printDBG('HelloWorld.handleService name[%s], category[%s]' % (name, category))
        self.currList = []

        if name is None:  # the main menu of the host
            self.listsTab(self.MENU, {'name': 'category'})
        elif category == 'list_videos':
            self.listVideos(self.currItem)
        else:
            printExc()

        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        # False = no search history
        CHostBase.__init__(self, HelloWorld(), False, [])
