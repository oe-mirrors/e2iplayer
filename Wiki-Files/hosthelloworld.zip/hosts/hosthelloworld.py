# -*- coding: utf-8 -*-
###################################################
# LOCAL import
###################################################
from Plugins.Extensions.IPTVPlayer.components.iptvplayerinit import TranslateTXT as _
from Plugins.Extensions.IPTVPlayer.components.ihost import CHostBase, CBaseHostClass
from Plugins.Extensions.IPTVPlayer.tools.iptvtools import printDBG, printExc, MergeDicts
from Plugins.Extensions.IPTVPlayer.tools.iptvtypes import strwithmeta
from Plugins.Extensions.IPTVPlayer.libs.e2ijson import loads as json_loads, dumps as json_dumps
from Plugins.Extensions.IPTVPlayer.libs import ph
from Plugins.Extensions.IPTVPlayer.libs.urlparserhelper import getDirectM3U8Playlist
###################################################

###################################################
# FOREIGN import
###################################################
import re
import datetime
###################################################

def gettytul():
    return 'https://helloworld.com/'  

class HelloWorld(CBaseHostClass):
 
    def __init__(self):
        
        CBaseHostClass.__init__(self, {'history':'helloworld', 'cookie':'helloworld.cookie'}) 
        
        # various urls
        self.MAIN_URL = 'https://helloworld.com/'
        self.SEARCH_URL = 'https://helloworld.com/search'

        # url for default icon
        self.DEFAULT_ICON_URL = "https://helloworld.com/themes/hellotheme/images/helloworld-badge-footer.png"

        # default header and http params
        self.HTTP_HEADER = self.cm.getDefaultHeader(browser='chrome')        
        self.defaultParams = {'header':self.HTTP_HEADER, 'use_cookie': True, 'load_cookie': True, 'save_cookie': True, 'cookiefile': self.COOKIE_FILE}
        
    def getPage(self, url, addParams = {}, post_data = None):
        if addParams == {}:
            addParams = dict(self.defaultParams)
        return self.cm.getPage(url, addParams, post_data)

    
    def getLinksForVideo(self, cItem):  
        printDBG("HelloWorld.getLinksForVideo [%s]" % cItem)

        videoUrl = cItem['url']
        linksTab=[]
        if self.up.checkHostSupport(videoUrl) == 1:
            return self.up.getVideoLinkExt(videoUrl)
        else:
            printDBG(videoUrl)
            
        return linksTab

    def listMainMenu(self, cItem):   
        printDBG('NameOfHost.listMainMenu')
        MAIN_CAT_TAB = [
            {'category':'page',            'title': _('This is a page')}
                       ]
        self.listsTab(MAIN_CAT_TAB, cItem)  

    # here you should add the functions you need to show users list of items (dirs, videos)           
    def listItems (self, cItem):
        printDBG('NameOfHost.listItems')

        self.addVideo({'title': 'link 1', 'url': 'https://www.youtube.com/watch?v=OfaBZvvL_7M'})
        self.addVideo({'title': 'link 2', 'url': 'https://www.youtube.com/watch?v=rOU4YiuaxAM'})
        self.addVideo({'title': 'link 3', 'url': 'https://www.youtube.com/watch?v=pRKqlw0DaDI'})
                        
    def handleService(self, index, refresh = 0, searchPattern = '', searchType = ''):
        # main cycle to move through items.
        printDBG('NameOfHost.handleService start')
        
        CBaseHostClass.handleService(self, index, refresh, searchPattern, searchType)

        name     = self.currItem.get("name", '')
        category = self.currItem.get("category", '')
        
        printDBG( "handleService: >> name[%s], category[%s] " % (name, category) )
        self.currList = []
        
        #MAIN MENU
        if name == None:
            self.listMainMenu({'name':'category'})
        elif category == 'page':
            self.listItems(self.currItem)
        else:
            printExc()
        
        CBaseHostClass.endHandleService(self, index, refresh)


class IPTVHost(CHostBase):

    def __init__(self):
        CHostBase.__init__(self, HelloWorld(), True, [])
    
